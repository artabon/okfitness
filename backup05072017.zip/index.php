<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title>OK Fitness - Optimum Kinetics Fitness</title>
<meta name="description" content="Official website of Optimum Kinetics Fitness | Ok Fitness" />

<!-- Twitter Card data -->
<meta name="twitter:card" value="Official website of Optimum Kinetics Fitness | OK Fitness">

<!-- Open Graph data -->
<meta property="og:title" content="OK Fitness : Optimum Kinetics" />
<meta property="og:type" content="article" />
<meta property="og:url" content="" />
<meta property="og:image" content="" />
<meta property="og:description" content="Official website of Optimum Kinetics Fitness | Ok Fitness" />

<link href="https://fonts.googleapis.com/css?family=Montserrat:100,300,400,500" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="style.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
// Select all links with hashes
$(document).ready(function(){
  $('a[href*="#"]')
  // Remove links that don't actually link to anything
  .not('[href="#"]')
  .not('[href="#0"]')
  .click(function(event) {
    // On-page links
    if (
      location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '')
      &&
      location.hostname == this.hostname
    ) {
      // Figure out element to scroll to
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      // Does a scroll target exist?
      if (target.length) {
        // Only prevent default if animation is actually gonna happen
        event.preventDefault();
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 1000, function() {
          // Callback after animation
          // Must change focus!
          var $target = $(target);
          $target.focus();
          if ($target.is(":focus")) { // Checking if the target was focused
            return false;
          } else {
            $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
            $target.focus(); // Set focus again
          };
        });
      }
    }
  });

  $("div.modal, div#overlay").click(function(){
    $("div.modal").hide();
    $("div#overlay").hide();
  });

});

function showDiv(name) {
  $("div#"+name).show();
  $("div#overlay").show();
  var scrollTarget = "div#"+name;
  if($("div#"+name).hasClass("trainer")) {
    scrollTarget = "div#trainers";
  } else if($("div#"+name).hasClass("about")) {
    scrollTarget = "about";
  }
  $(scrollTarget)[0].scrollIntoView();
}

</script>
</head>

<body>
  <header id="home">
    <nav>
      <div id="logo"></div>
      <ul id="topmenu">
        <li><a href="#home">Home</a></li>
        <li><a href="#about">About Us</a></li>
        <li><a href="#services">Our Services</a></li>
        <li><a href="#trainers">Meet Trainers</a></li>
      </ul>
      <a id="signup" class="header--button__signup" href="#contactform">Sign Up</a>
    </nav>
    <h1 id="header--h1">Unique regimen of fitness training</h1>
    <span id="header--text">Customized to fit your goals and fitness level</span>
    <div class="button__center"><a id="learnmore" class="header--button__signup" href="#about">Learn More</a></div>
    <div id="featured">
      <div class="featured--card specialborderbottom">
        <h1>Our Services</h1>
        <span>Aims to provide one-on-one fitness training, conditioning and strengthening</span>
        <div id="services--bg"></div>
      </div>
      <div class="featured--card__center">
        <div class="featured--logo" ></div>
        <h1>Get Started Today!</h1>
        <span>One-on-one fitness training</span>
        <div class="button__center"><a href="#contactform" class="header--button__signup">Start Now</a></div>
      </div>
      <div class="featured--card specialborderbottom">
        <h1>Meet The Trainers</h1>
        <span>Qualified, positive, and goal-oriented personal trainers</span>
        <div id="meetthetrainers--bg"></div>
      </div>
    </div>
  </header>
  <main>
    <div id="home2">
      <h2>OK fitness is a Philippine-based personal training company that aims to provide one-on-one fitness training, conditioning, and strengthening.</h2>
    </div>
    <div id="services">
      <h1>Our Services</h1>
      <span>Aims to provide one-on-one fitness training, conditioning, and strengthening.</span>
      <div id="services--menu">
        <div class="services--menuitem">
          <div class="services--menuitemlogo one"></div>
          <h3>Strength and Conditioning</h3>
          <span>Competition and sports-specific training, and peak performance planning</span>
        </div>
        <div class="services--menuitem">
          <div class="services--menuitemlogo two"></div>
          <h3>Medical Training</h3>
          <span>Hypertension, diabetes, osteoporosis, weight management, and general health.</span>
        </div>
        <div class="services--menuitem">
          <div class="services--menuitemlogo three"></div>
          <h3>Body Building</h3>
          <span>Increase in muscle mass, weight gaining, and heavy lifting.</span>
        </div>
        <div class="services--menuitem">
          <div class="services--menuitemlogo four"></div>
          <h3>Endurance Training</h3>
          <span>Cardiovascular training, weight loss, and metabolism boost.</span>
        </div>
        <div class="services--menuitem">
          <div class="services--menuitemlogo five"></div>
          <h3>Youth Training</h3>
          <span>Interactive and hip! For the younger population that might need</span>
        </div>
        <div class="services--menuitem">
          <div class="services--menuitemlogo six"></div>
          <h3>Pilates / Core</h3>
          <span>Spine strength, abdominals,  flexibility.</span>
        </div>
        <div class="services--menuitem">
          <div class="services--menuitemlogo seven"></div>
          <h3>Power Stretch</h3>
          <span>Sports massage,  facilitated stretching.</span>
        </div>
        <div class="services--menuitem">
          <div class="services--menuitemlogo eight"></div>
          <h3>Post Rehab</h3>
          <span>Pain management, post-injury  strengthening, injury prevention</span>
        </div>
        <div class="services--menuitem">
          <div class="services--menuitemlogo nine"></div>
          <h3>Group Class</h3>
          <span>Fun and challenging activities,  minimum of four participants.</span>
        </div>
      </div>
    </div>
    <div id="about">
      <h1>About Us</h1>
      <h2>Hey there! We are OK FITNESS, a group of energetic, fun-loving and goal-oriented motivational exercise specialists that would love to meet and train you.</h2>
      <span>
        We are committed to turning you into the best version of yourself through working on your capabilities, maximizing your
body’s potential to move and sweat, and move and sweat some more. Let’s plan and set an achievable goal with the right time frame, gradually working you up to a stronger and better you!
      </span>
      <div class="button__center"><a href="javascript:showDiv('aboutmodal');" class="learnmore--link">Learn More</a></div>
    </div>
     <div id="trainers">
      <h1>Meet The Trainers</h1>
      <span>Comprised of qualified, positive and goal-oriented personal trainers, each with unique training skills and programs</span>
      <div id="trainers--menu">
        <div class="trainers--menuitem">
          <div class="trainers--menuitemlogo"></div>
          <h3>Johanne Laue</h3>
          <span>Strength and Conditioning, Core Training, Speed and Agility, and more </span>
          <a href="javascript:showDiv('johannes');" class="learnmore--link">Learn More</a>
        </div>
        <div class="trainers--menuitem">
          <div class="trainers--menuitemlogo two"></div>
          <h3>David Victorino</h3>
          <span>Strength and Conditioning, Endurance Training, Muscle Gaining, and more </span>
          <a href="javascript:showDiv('david');" class="learnmore--link">Learn More</a>
        </div>
        <div class="trainers--menuitem">
          <div class="trainers--menuitemlogo three"></div>
          <h3>Kenneth Calara</h3>
          <span>Body Building, Weight Loss, Functional Training, and more </span>
          <a href="javascript:showDiv('kenneth');" class="learnmore--link">Learn More</a>
        </div>
      </div>
    </div>
    <div id="contactform">
      <h1>Get Started Today!</h1>
      <span>Fill-up the form and we’ll get back to you as soon as we can!</span>
      <form enctype="multipart/form-data" autocomplete="off" method="post" name="contact" id="frmcontact" action="https://formspree.io/clients@optimumkinetics.com">
        <input class="input__halfscreen" id="firstname" name="firstname" type="text" placeholder="First Name" />
        <input class="input__halfscreen" id="lastname" name="lastname" type="text" placeholder="Last Name" />
        <input class="input__halfscreen" id="email" name="email" type="text" placeholder="Email Address" />
        <input class="input__halfscreen" id="mobile" name="mobile" type="text" placeholder="Mobile Number" />
        <div class="input__fullscreen styledselect">
          <select name="service" id="service">
          <option value=" ">Choose Service</option>
          <option value="Strength and Conditioning">Strength and Conditioning</option>
          <option value="Medical Training">Medical Training</option>
          <option value="Body Building">Body Building</option>
          <option value="Endurance Training">Endurance Training</option>
          <option value="Youth Training">Youth Training</option>
          <option value="Pilates / Core">Pilates / Core</option>
          <option value="Power Stretch">Power Stretch</option>
          <option value="Post Rehab">Post Rehab</option>
          <option value="Group Class">Group Class</option>
          </select>
        </div>
        <textarea name="message" class="input__fullscreen" placeholder="Type your message"></textarea>
        <div class="button__center"><a id="signup" class="header--button__signup" href="javascript:document.getElementById('frmcontact').submit();">Send Now</a></div>
      </form>
    </div>
    <div id="contact" class="specialborderbottom">
      <div class="contact--container">
        <div class="contact--div__halfscreen">
          <h1>For Appointments</h1>
          <div class="contact__phone detail"><a href="tel:+639991018928">+63 999 101 8928</a></div>
          <div class="contact__email detail"><a href="mailto:clients@optimumkinetics.com">clients@optimumkinetics.com</a></div>
        </div>
        <div class="contact--div__halfscreen">
          <h1>For Careers</h1>
          <div class="contact__email detail"><a href="mailto:clients@optimumkinetics.com">clients@optimumkinetics.com</a></div>
        </div>
      </div>
    </div>
  </main>
  <footer>
    <div class="footer--copyright">
      Copyright &copy; 2016 OK Fitness. All rights reserved.
    </div>
    <div class="footer--social">
      <a href="#" class="footer--icon facebook"></a>
      <a href="#" class="footer--icon twitter"></a>
      <a href="#" class="footer--icon intsagram"></a>
      <a href="#" class="footer--icon linkedin"></a>
    </div>
  </footer>
  <div id="overlay"></div>
  <div id="aboutmodal" class="modal about">
    <br/><br/>
    Hey there! We are OK FITNESS, a group of energetic, fun-loving and goal-oriented motivational exercise specialists that would love to meet and train you. We are committed to turning you into the best version of yourself through working on your capabilities, maximizing your body’s potential to move and sweat, and move and sweat some more. Let’s plan and set an achievable goal with the right time frame, gradually working you up to a stronger and better you!
    <br/><br/>
    OK Fitness is a Philippine-based personal training company that aims to provide one-on-one fitness training, conditioning and strengthening. Comprised of certified, positive and goal-oriented personal trainers, each trainer offers unique training skills and programs that help clients attain their fitness goals; all achievable by focusing on optimum movement, rest, recovery and body adaptation.
    <br/><br/>
    Each OK Fitness trainer offers a unique fitness training regimen customized to fit your goals and fitness level. Each training session is aimed to utilize your body to its maximum capacity - vastly improving on movement, strength, endurance, health, body composition, and concentration. OK Fitness trainers not only train you, they teach you the importance of each exercise and how to perform them correctly, allowing you to gradually perform the routine on your own. Personal training sessions can be performed in the comforts of your own home, select clubs and hotel facilities.
    <br/><br/>
  </div>
  <div id="david" class="modal trainer">
    <div class="trainers--menuitemlogo two"></div>
    <h2>David Victorio</h2>
    <br/><br/>
    <h3>Certifications</h3> <br/>
    B.S. in Sports Science at the University of the Philippines <br/>
    American council on exercise certified personal trainer<br/>
    Physical education teacher to high school and college students<br/><br/>
    <h3>Expertise</h3> <br/>
    Strength and Conditioning<br/>
    Endurance training <br/>
    Muscle gaining <br/>
    Kettlebell training <br/>
    Power lifting <br/>
    Youth training<br/>
    Home Training <br/>
  </div>
  <div id="johannes" class="modal trainer">
    <div class="trainers--menuitemlogo one"></div>
    <h2>Johannes Laue</h2>
    <br/><br/>
    <h3>Certifications</h3> <br/>
    B.S. in Sports Science at University of Santo Tomas<br/>
    Intermediate mat pilates at Peak Pilates <br/><br/>
    <h3>Expertise</h3> <br/>
    Strength and Conditioning<br/>
    Resistance training / Weights training<br/>
    Core training<br/>
    Speed and Agility<br/>
    Post Rehab<br/>
    Home Training<br/>
  </div>
  <div id="kenneth" class="modal trainer">
    <div class="trainers--menuitemlogo three"></div>
    <h2>Kenneth Calara</h2>
    <br/><br/>
    <h3>Certifications</h3> <br/>
    Licensed Physical Therapist 2010<br/>
    Rocktape Kinesiology / Power taping Certified 2010<br/>
    American Council on Exercise Certified 2012 <br/>
    <br/><br/>
    <h3>Expertise</h3> <br/>
    Strength and Conditioning <br/>
    Body Building <br/>
    Weight Loss <br/>
    Functional Training<br/>
    Sports Conditioning <br/>
    Manual Muscle Release <br/>
    Power Stretch
     <br/>
  </div>
</body>
</html>
